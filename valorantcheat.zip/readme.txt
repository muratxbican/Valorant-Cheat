!!Filenames Edited as Meaningless for Protection!!
blackmath = Vanguard Protection 
ping = if you have ping it will help to lower it some files can be closed

!!!!FILE NAMED RANDOM IS A CHEAT FILE!!!!